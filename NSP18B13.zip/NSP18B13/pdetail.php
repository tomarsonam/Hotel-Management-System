  <?php
  session_start();
    ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <title>Home page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="js/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

  </head><style>
  input[type=text],[type=submit],[type=date]
  {margin-top: 20%;
    height: 70px;width: 200px;
    padding: 20px;outline:none;

  }
  body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
  }
  .container{
    max-width: 1000px;
  }
  .header {
      padding: 30px;
      text-align: center;
      background: #1abc9c;
      color: white;
  }

  .topnav {
    overflow: hidden;
    background-color: #333;
  }

  .topnav a {
    float: left;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
  }

  .topnav a:hover {
    background-color: #ddd;
    color: black;
  }

  .active {
    background-color: #4CAF50;
    color: white;
  }

  .topnav .icon {
    display: none;
  }

  @media screen and (max-width: 600px) {
    .topnav a:not(:first-child) {display: none;}
    .topnav a.icon {
      float: right;
      display: block;
    }
  }

  @media screen and (max-width: 600px) {
    .topnav.responsive {position: relative;}
    .topnav.responsive .icon {
      position: absolute;
      right: 0;
      top: 0;
    }
    .topnav.responsive a {
      float: none;
      display: block;
      text-align: left;
    }
  }
  h2 {
      color: white;
      text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
  }
  h1 {
      color: white;
      text-shadow: 2px 2px 4px #000000;
  }
  h1 {
      text-shadow: 0 0 3px #FF0000;
  }
  </style>
  </head>
  <body>

  <script>
  function myFunction() {
      var x = document.getElementById("myTopnav");
      if (x.className === "topnav") {
          x.className += " responsive";
      } else {
          x.className = "topnav";
      }
  }
 function validation(){ 

    var inputfname3 = document.getElementById('inputfname3').value;
    {
      if(inputfname3 ==""){
      return false;
    }
    if((inputfname3.length <=4) || (inputfname3.length> 30)){
      document.getElementById('inputfname3').innerHTML="** user length mustbe 3 to 29" ;
      return false;
    }
    if(!isNaN(inputfname3)){
      return false;
    }
}
var inputlname3 = document.getElementById('inputlname3').value;
    {

      if(inputlname3 ==""){
      return false;
    }
    if((inputlname3.length <=4) || (inputlname3.length> 30)){
      document.getElementById('inputlname3').innerHTML="** user length mustbe 3 to 29" ;
      return false;
    }
    if(!isNaN(inputlname3)){
      document.getElementById('inputlname3').innerHTML="** only characters are allowed " ;
      return false;

}
}

var inputaddress3 = document.getElementById('inputaddress3').value;
    {

      if(inputaddress3 ==""){
      return false;
    }
    if((inputaddress3.length <=4) || (inputaddress3.length> 100)){
      document.getElementById('inputaddress3').innerHTML="** user length mustbe 3 to 100" ;
      return false;
    }
    if(!isNaN(inputaddress3)){
      document.getElementById('inputaddress3').innerHTML="** only characters are allowed " ;
      return false;

}
}
}
  </script>


  <div class="container-fluid">
    <div class="row">

      <div class="navbar navbar-inverse navbar-fixed-top " style="background-color: white;font-size: 18px">

        <ul class="nav nav-tabs">
         
      <li ><a href="index.php" style="margin-top: 50px">Home</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="margin-top: 50px">Event<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="eventlist.php">Event list</a></li>
          <li><a href="event.php">Event venue</a></li>                      
        </ul>
      </li>
     <li><a href="services.php" style="margin-top: 50px">Services</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="margin-top: 50px">Gallery<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="gwed.php">Wedding</a></li>
          <li><a href="gbirth.php">Birthday</a></li>
          <li><a href="gmusic.php">Music-concerts</a></li>
          <li><a href="gconf.php">Conference</a></li>
 
          <li><a href="gbusi.php">Business Meetings</a></li>
          <li><a href="genag.php">Engagements</a></li>                        
        </ul>
      </li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="margin-top: 50px">Pages<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="pdetail.php">Detail page</a></li>
          <li><a href="#">My Profile</a></li>
          <li><a href="#">Edit profile</a></li>
          <li><a href="pblog.php">Blog</a></li>   
          <li><a href="privacy.php">Privacy policy</a></li> 
          <li><a href="piechart.php">Chart</a></li> 
          <li><a href="pteam.php">Team</a></li>                       
        </ul>
      </li>
      <li><a href="booknow.php" style="margin-top: 50px">Book Now</a></li>
      <li><a href="about.php" style="margin-top: 50px">About us</a></li>
      <li><a href="faq.php" style="margin-top: 50px">FAQ'S</a></li>
      <li><a href="contact.php" style="margin-top: 50px">Contact us</a></li>
      <?php if(!empty($_SESSION["name"])) { 
          echo "<li><a>".$_SESSION["name"]."</a></li>";
          echo "<li><a href='logout.php'>Logout</a></li>";
        if($_SESSION["TYPE"]=="admin"){
       echo "<li><a href='admin.php'>Admin</a></li>";
        } }else{
        ?>
      <li><a data-toggle="modal" data-target="#myModal" data-backdrop="false" style="margin-left:400px ">
      Login
    </a>

  
    <!-- The Modal -->
    <div class="modal fade" id="myModal">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
        
          <!-- Modal Header -->
            <div class="modal-header">
                  <button type="button" class="close" 
                     data-dismiss="modal">
                         <span aria-hidden="true">&times;</span>
                         <span class="sr-only">Close</span>
                  </button>
                 <center> <h4 class="modal-title" id="myModalLabel">
                      Login
                  </h4></center>
              </div>
              
              <!-- Modal Body -->
              <div class="modal-body">
                  
                  <form action="login.php" method="POST" class="form-horizontal" role="form">
                    <div class="form-group">
                      <label  class="col-sm-3 control-label"
                                for="inputEmail3">Email</label>
                      <div class="col-sm-7">
                          <input type="email" class="form-control" 
                          id="inputEmail3" name="inputEmail3" placeholder="Email" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputPassword3" >Password</label>
                      <div class="col-sm-7">
                          <input type="password" class="form-control"
                              id="inputPassword3" name="inputPassword3" placeholder="Password" required>
                      </div>
                    </div>
                    

                    <div class="form-group">
                      <div class="col-sm-offset-2 col-sm-10">
                        <div class="checkbox">
                          <label>
                              <input type="checkbox"/> Remember me
                          </label>
                        </div>
                      </div>
                    </div>              
              <?php
  //Include GP config file && User class
  include_once 'gpConfig.php';
  include_once 'User.php';

  if(isset($_GET['code'])){
    $gClient->authenticate($_GET['code']);
    $_SESSION['token'] = $gClient->getAccessToken();
    header('Location: ' . filter_var($redirectURL, FILTER_SANITIZE_URL));
  }

  if (isset($_SESSION['token'])) {
    $gClient->setAccessToken($_SESSION['token']);
  }

  if ($gClient->getAccessToken()) {
    //Get user profile data from google
    $gpUserProfile = $google_oauthV2->userinfo->get();
    
    //Initialize User class
    $user = new User();
    
    //Insert or update user data to the database
      $gpUserData = array(
          'oauth_provider'=> 'google',
          'oauth_uid'     => $gpUserProfile['id'],
          'first_name'    => $gpUserProfile['given_name'],
          'last_name'     => $gpUserProfile['family_name'],
          'email'         => $gpUserProfile['email'],
          'gender'        => $gpUserProfile['gender'],
          'locale'        => $gpUserProfile['locale'],
          'picture'       => $gpUserProfile['picture'],
          'link'          => $gpUserProfile['link']
      );
      $userData = $user->checkUser($gpUserData);
    
    //Storing user data into session
    $_SESSION['userData'] = $userData;
    
    //Render facebook profile data
      if(!empty($userData)){
          $output = '<h1>Google+ Profile Details </h1>';
          $output .= '<img src="'.$userData['picture'].'" width="300" height="220">';
          $output .= '<br/>Google ID : ' . $userData['oauth_uid'];
          $output .= '<br/>Name : ' . $userData['first_name'].' '.$userData['last_name'];
          $output .= '<br/>Email : ' . $userData['email'];
          $output .= '<br/>Gender : ' . $userData['gender'];
          $output .= '<br/>Locale : ' . $userData['locale'];
          $output .= '<br/>Logged in with : Google';
          $output .= '<br/><a href="'.$userData['link'].'" target="_blank">Click to Visit Google+ Page</a>';
          $output .= '<br/>Logout from <a href="logout.php">Google</a>'; 
      }else{
          $output = '<h3 style="color:red">Some problem occurred, please try again.</h3>';
      }
  } else {
    $authUrl = $gClient->createAuthUrl();
    $output = '<a href="'.filter_var($authUrl, FILTER_SANITIZE_URL).'"><img src="images/glogin.png" alt=""/ style="height:150px;width:300px;margin-left:100px"></a>';
   
  }
  ?>
  <html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Login with Google using PHP by CodexWorld</title>
  <style type="text/css">
  h1{font-family:Arial, Helvetica, sans-serif;color:#999999;}
  </style>
  </head>
  <body>
  <div><?php echo $output; ?></div>
  </body>
  </html></div>
          <a href="forget.php">Forget Password</a>
          <!-- Modal footer -->
          <div class="modal-footer">
            <div class="col-sm-1">
           <input type="submit" name="signup">
         </div>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div></form>
          
        </div>
      </div>
    </div></li>
    <li><a data-toggle="modal" data-target="#mysignup" data-backdrop="false">
      Sign Up
    </a>

    <!-- The Modal -->
    <div class="modal fade" id="mysignup">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
        
          <!-- Modal Header -->
            <div class="modal-header">
                  <button type="button" class="close" 
                     data-dismiss="modal">
                         <span aria-hidden="true">&times;</span>
                         <span class="sr-only">Close</span>
                  </button>
                  <center><h4 class="modal-title" id="myModalLabel">
                      Sign Up
                  </h4></center>
              </div>
              
              <!-- Modal Body -->
              <div class="modal-body">
 <form class="form-horizontal" name="f1" role="form" action="signup.php" method="POST" onsubmit="return validation()">
                    <div class="form-group">
                      <label  class="col-sm-3 control-label"
                                for="inputText3">First Name</label>
                      <div class="col-sm-9">
                          <input type="inputText3" class="form-control" 
                          id="inputfname3" name="inputfname3" placeholder="First Name" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Last Name</label>
                      <div class="col-sm-9">
                          <input type="inputText3" class="form-control"
                              id="inputlname3"  name="inputlname3" placeholder="Last Name" required>
                      </div>
                    </div>
                    
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputdate3" >Birthday</label>
                      <div class="col-sm-9">
                          <input type="inputdate3" class="form-control"
                              id="inputdate3" id="inputDate3" placeholder="mm/dd/yy" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Mobile No.</label>
                      <div class="col-sm-9">
                          <input type="inputtext3" class="form-control"
                              id="inputmobile3" name="inputmobile3" placeholder="Mobile No." required maxlength="10" minlength="10">
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Adhar No.</label>
                      <div class="col-sm-9">
                          <input type="inputext3" class="form-control"
                              id="inputadhar3" placeholder="Adhar No." minlength="16" maxlength="16" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="email" >Email</label>
                      <div class="col-sm-9">
                          <input type="email" class="form-control"
                              id="inputEmail3"  name="inputEmail3" placeholder="Email" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputPassword3" >Password</label>
                      <div class="col-sm-9">
                          <input type="password" class="form-control"
                              id="inputPassword3"  name="inputPassword3" placeholder="Password"  maxlength="16" minlength="6" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Address</label>
                      <div class="col-sm-9">
                          <input type="inputText3" class="form-control"
                              id="inputaddress3" name="inputaddress3" placeholder="Address" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-sm-offset-2 col-sm-10">
                        <div class="checkbox">
                          <label>
                              <input type="checkbox"/> Remember me
                          </label>
                        </div>
                      </div>
                    </div>              
              </div>
          
          <!-- Modal footer -->
          <div class="modal-footer">
            <div class="col-sm-1">
           <input type="submit" name="signup">
         </div>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div></form>
          
        </div>
      </div>
    </div></li>
    </ul>
  </div>

      </div><?php } ?>
      
    </div>

  </div><br><br><br><br><br>



<div class="row">
      <img src="images/bck.jpg" style="height: 350px; width: 100%;"><br><br>
  </div>
  <div style="position: absolute;top:50px; left:0;width: 100%; height: 400px; background-color: rgba(0,0,0,0.4); ">
      <div style="display: flex;justify-content: center;margin-top: 200px;">
        <center><div><div><font style="font-size: 60px; color: white;"><b>Event Details</b></font></div>
</div>
</center>
</div>
</div>
<div class="row"><br><br>
  <div class="col-md-9 col-md-offset-1 well" style="background-color: white">
<center><font size="3px";><h1><b>Know about us</b></h1></font>
  <h4><b><center>Welcome to Kaliedeoscope Events</center></b></h4>
 <font size="3px"><p>Kaliedeoscope Events is Destination wedding Planner and event management company in Jaipur, Rajasthan India , managing events across all major cities in India. Since our establishment, we have continuously strived towards flawless execution of ideas.<br>

No matter what the requirements may be, our first priority lies in gaining an in-depth understanding of how your business works, what you hope to achieve and what we can do to deliver results that exceed all expectations.<br>

At Kaliedeoscope Event’s, your money is important, to you and us, we ensure cost-effective performance, accountability, flexibility and most of all we treat your event like it is ours. Whatever your budget, we have solutions you won’t find elsewhere. At Events Across, we aim to offer an efficient, fast and friendly service. All of our staff are highly trained and will welcome you with a smile! .</p></font>

</center><br><br>
<p>______________________________________________________________________________________________________________________________________________</p><br>
<div class="col-md-5">
   <div id="googleMap" style="height: 400px;width: 100%;"></div>
<script type="text/javascript">
  function myMap(){
    var mapProp={
      center:new google.maps.LatLng(26.9124,75.7873),
      zoom:5,
    };
    var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);
  }
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCKyREharlDT0ZgEvdkcL8ujl4XNgdk4XQ&callback=myMap"></script>

</div>
<div class="col-md-1"></div>
<div class="col-md-6">
  <font style="font-size: 30px;"><b>ADDRESS:</b></font><br><br>
      <i class="fa fa-location-arrow" style="font-size:25px; color: grey">Location:PIET , Jaipur</i><br><br><br>
      <font style="font-size: 20px;"><b>NEAR BY::</b></font><br><br>
      <i class="fa fa-plane" style="font-size:25px; color: grey">8km</i><br><br>
      <i class="fa fa-bus" style="font-size:25px; color: grey">1km</i><br><br>
      <i class="fa fa-train" style="font-size:25px; color:grey">14km(from Gandhi Nagar )</i><br><br>
</div>
</div>
</div><br><br><br>
<div class="row">
  <div class="col-md-9 col-md-offset-1 well" style="background-color: white">
    <h3><b>Photo Gallery</b></h3>
    <div class="col-md-4">
    <div class="thumbnail">
      <a href="image/w1.jpg">
        <img src="image/w1.jpg" alt="Lights" style="height: 250px;width:100%">
        <div class="caption">
          <p>Weeding...</p>
        </div>
      </a>
    </div>
  </div>
  <div class="col-md-4">
    <div class="thumbnail">
      <a href="image/wed1.jpg">
        <img src="image/b1.jpg" alt="Nature" style="height: 250px;width:100%">
        <div class="caption">
          <p>Weeding...</p>
        </div>
      </a>
    </div>
  </div>
  <div class="col-md-4">
    <div class="thumbnail">
      <a href="image/e5.jpg">
        <img src="image/e5.jpg" alt="Fjords" style="height: 250px;width:100%">
        <div class="caption">
          <p>Engagement...</p>
        </div>
      </a>
    </div>
  </div>
    <div class="col-md-4">
    <div class="thumbnail">
      <a href="image/wed.jpg">
        <img src="image/wed4.jpg" alt="Lights" style="height: 250px;width:100%">
        <div class="caption">
          <p>Weeding...</p>
        </div>
      </a>
    </div>
  </div>
  <div class="col-md-4">
    <div class="thumbnail">
      <a href="image/wed1.jpg">
        <img src="image/b1.jpg" alt="Nature" style="height: 250px; width:100%">
        <div class="caption">
          <p>Businness...</p>
        </div>
      </a>
    </div>
  </div>
  <div class="col-md-4">
    <div class="thumbnail">
      <a href="image/e3.jpg">
        <img src="image/e2.jpg" alt="Fjords" style="height: 250px; width:100%">
        <div class="caption">
          <p>Engagement...</p>
        </div>
      </a>
    </div>
  </div>
    
  </div>
</div><br>
<div class="row">
  <div class="col-md-9 col-md-offset-1 well" style="background-color: white">
<h4><b><center>Copyright Notice</center></b></h4>
 <font size="3px"><p> This website and its content is copyright of Kaliedeoscope - © Kaliedeoscope 2018 and beyond. All rights reserved.

The name Kaliedeoscope and belonging logo(s) and other brand elements are trademarks and may not be copied, altered or redistributed without permission.

You may not, except with our express written permission, distribute or commercially exploit the content. Nor may you transmit it or store it in any other website or other form of electronic retrieval system, without permission.

Now, please enjoy Kaliedeoscope and play nice</p></font>


</div>

  <div class="row">
  <div class="col-md-9 col-md-offset-1 well" style="background-color: white">
<center><font size="3px";><h2><b>TERMS & CONDITIONS</b></h2></font></center><br>
<h4><b>Welcome to our website! We hope you enjoy your stay.If you sign up to our service, you are agreeing to comply with and be bound by the following terms and conditions of use, which together with our privacy policy govern </b></h4>
 <font size="3px"><p>1.We're using cookies to improve your use of our service.<br><br>2.Part of our service are emails sent to inform you about important news related to your user account, events you are connected to or about our product and service in general.<br><br>3.The content of the pages of this website is for your general information and use only. It is subject to change without notice.<br><br>4.In no event will we be liable for any loss or damage including without limitation, indirect or consequential loss or damage, or any loss or damage whatsoever arising from loss of data or profits arising out of, or in connection with, the use of this website.<br><br>5.Every effort is made to keep the website up and running smoothly. However, Kaliedeoscope takes no responsibility for, and will not be liable for, the website being temporarily unavailable due to technical issues beyond our control.<br><br>6.Your use of any information or materials on this website is entirely at your own risk, for which we shall not be liable. It shall be your own responsibility to ensure that any products, services or information available through this website meet your specific requirements.<br><br>7.Your only solution with respect to any dissatisfaction with the Kaliedeoscope service, or any term of this Terms and Conditions, or any policy or practice of operating our service, or any content transmitted through our service, is to terminate your account and refrain from using the service any further.<br> </p></font>


</div>

</div>
<div class="row">
  <div class="col-md-9 col-md-offset-1 well" style="background-color: white">
<center><font size="3px";><h2><b>POLICIES</b></h2></font></center><br>
<h4><b>1.Cancelation</b></h4>
 <font size="3px"><p> For any subscription to a Paid Service, that subscription will continue unless and until you cancel your subscription, or we terminate it. You must cancel your subscription before it renews in order to avoid billing of the next period's (i.e., 3 months’ or 1 year’s) subscription fees to your Payment Method. We will bill the periodic subscription fee to the Payment Method you provide to us during registration (or to a different Payment Method if you change your account information).
</p><br>

<h4><b>2. Refund</b></h4>
<p>Any fees charged to your account are non-refundable except as expressly stated in these Terms. You agree to submit any dispute regarding any charge to your account in writing to Kaliedeoscope within thirty (30) days of the charge, otherwise that dispute will be waived, and the charge will be final and not subject to challenge. Refunds (if any) made pursuant to a dispute, are at the discretion of Kaliedeoscope.</p></font><br>

<h4><b>3.Taxes</b></h4>
<p>You are responsible for paying any governmental taxes imposed on your use of the Kaliedeoscope Services, including sales, use, or value added taxes. If requested, you will promptly furnish to Kaliedeoscope the applicable receipts or certificates regarding such remittances as soon as reasonably practicable. To the extent that Kaliedeoscope is obligated to collect such taxes, Kaliedeoscope will charge your Payment Method or otherwise add the applicable to your billing account.</p></font><br><br><br>
</div>

</div>
<br><br>
  <div class="row well" style="background-color: grey;">  
      <div class="col-sm-3 well" style="background-color: grey; font-size: 18px; color: white ;border:none;border-right: 2px solid;height: 300px;">Disclaimer <br>FAQ <br> Terms & Condition <br> About Us <br> Privacy Policy</div>
      <div class="col-sm-3 col-sm-offset-1 well" style="background-color: grey; height: 300px;font-size: 18px; color: white;border:none;border-right: 2px solid;"><u style="font-size: 20px;">Follow Us On</u><br>Facebook <br>Instagram <br> Google+<br> Twitter</div>
      <div class="col-sm-3 col-sm-offset-2 well" style="background-color: grey; font-size: 18px;height: 300px; color: white;border:none;border-right: 2px solid;">
        Event Management System <br> 13/14 Saraswati Bihar,Goner Phtak <br> Jaipur city,302022 <br> Distt. Jaipur <br> Rajasthan <br>E-mail:-kaleidoscope@gmail.com <br>Contact No:- 1234567890
      </div>


</body>
</html>