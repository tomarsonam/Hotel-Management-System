<?php
  session_start();
    ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <title>Home page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="js/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

  </head><style>
  input[type=text],[type=submit],[type=date]
  {margin-top: 20%;
    height: 70px;width: 200px;
    padding: 20px;outline:none;

  }
  body
    {
      margin: 0;
      padding: 0;
      font-family: sans-serif;
    }
    .conatiner
    {
      width: 1280px;
    
      margin: 70px auto 0;
      display: flex;
      flex-direction: row;
      flex-wrap: wrap;
    }
    .conatiner .box
    {
      position: relative;
      width: 300px;
      height: 170px;
      margin: 10px;
      box-sizing: border-box;
      display: inline-block;
    }
    .conatiner .box .imgBox
    {
     
      position: relative;
      overflow: hidden;
    }
    .conatiner .box .imgBox img
    {
      max-width: 100%;
      transition: transform 2s;

    }
    .conatiner .box:hover .imgBox img
    {
      transform: scale(1.2);
      max-height: 100%;
      max-width: 100%;
    }
    .conatiner .box .details
    {
      position: absolute;;
      top: 10px;
      left: 10px;
      bottom: 10px;
      right: 10px;
      background-color: rgba(0,0,0,.8);
      transform: scaleY(0);
      transition: transform.5s
    }
        .conatiner .box:hover .details
        {
          transform: scaleY(1);
        }
    .conatiner .box .details .content
    {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      text-align: center;
      padding: 15px;
      color: #fff;
    }
       .conatiner .box .details .content h2
       {
        margin: 0;
        padding: 0;
        font-size: 20px;
        color: #ff0;

       }
       .conatiner .box .details .content p
       {
        margin: 10px 0 0;
        padding: 0;
       }
  </style>
  <div class="container-fluid">
    <div class="row">

      <div class="navbar navbar-inverse navbar-fixed-top ">

        <ul class="nav nav-tabs">
      <li class="active"><a href="#">Home</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Event<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="eventlist.php">Event list</a></li>
          <li><a href="event.php">Event venue</a></li>                      
        </ul>
      </li>
     <li><a href="services.php">Services</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Gallery<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="gwed.php">Wedding</a></li>
          <li><a href="gbirth.php">Birthday</a></li>
          <li><a href="gmusic.php">Music-concerts</a></li>
          <li><a href="gconf.php">Conference</a></li>
          <li><a href="gbusi.php">Business Meetings</a></li>
          <li><a href="genag.php">Engagements</a></li>                        
        </ul>
      </li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#">Pages<span class="caret"></span></a>
        <ul class="dropdown-menu">
                  <li><a href="pdetail.php">Detail page</a></li>
          <li><a href="#">My Profile</a></li>
          <li><a href="#">Edit profile</a></li>
          <li><a href="pblog.php">Blog</a></li>   
          <li><a href="privacy.php">Privacy policy</a></li> 
          <li><a href="piechart.html">Chart</a></li> 
          <li><a href="pteam.php">Team</a></li>                       
        </ul>
      </li>
      <li><a href="booknow.php">Book Now</a></li>
      <li><a href="about.php">About us</a></li>
      <li><a href="faq.php">FAQ'S</a></li>
      <li><a href="contact.php">Contact us</a></li>
      <?php if(!empty($_SESSION["name"])) { 
          echo "<li><a>".$_SESSION["name"]."</a></li>";
          echo "<li><a href='logout.php'>Logout</a></li>";
        if($_SESSION["TYPE"]=="admin"){
       echo "<li><a href='admin.php'>Admin</a></li>";
        } }else{
        ?>
      <li><a data-toggle="modal" data-target="#myModal" data-backdrop="false">
      Login
    </a>

    <!-- The Modal -->
    <div class="modal fade" id="myModal">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
        
          <!-- Modal Header -->
            <div class="modal-header">
                  <button type="button" class="close" 
                     data-dismiss="modal">
                         <span aria-hidden="true">&times;</span>
                         <span class="sr-only">Close</span>
                  </button>
                 <center> <h4 class="modal-title" id="myModalLabel">
                      Login
                  </h4></center>
              </div>
              
              <!-- Modal Body -->
              <div class="modal-body">
                  
                  <form action="login.php" method="POST" class="form-horizontal" role="form">
                    <div class="form-group">
                      <label  class="col-sm-3 control-label"
                                for="inputEmail3">Email</label>
                      <div class="col-sm-7">
                          <input type="email" class="form-control" 
                          id="inputEmail3" name="inputEmail3" placeholder="Email" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputPassword3" >Password</label>
                      <div class="col-sm-7">
                          <input type="password" class="form-control"
                              id="inputPassword3" name="inputPassword3" placeholder="Password" required>
                      </div>
                    </div>
                    

                    <div class="form-group">
                      <div class="col-sm-offset-2 col-sm-10">
                        <div class="checkbox">
                          <label>
                              <input type="checkbox"/> Remember me
                          </label>
                        </div>
                      </div>
                    </div>              
              <?php
  //Include GP config file && User class
  include_once 'gpConfig.php';
  include_once 'User.php';

  if(isset($_GET['code'])){
    $gClient->authenticate($_GET['code']);
    $_SESSION['token'] = $gClient->getAccessToken();
    header('Location: ' . filter_var($redirectURL, FILTER_SANITIZE_URL));
  }

  if (isset($_SESSION['token'])) {
    $gClient->setAccessToken($_SESSION['token']);
  }

  if ($gClient->getAccessToken()) {
    //Get user profile data from google
    $gpUserProfile = $google_oauthV2->userinfo->get();
    
    //Initialize User class
    $user = new User();
    
    //Insert or update user data to the database
      $gpUserData = array(
          'oauth_provider'=> 'google',
          'oauth_uid'     => $gpUserProfile['id'],
          'first_name'    => $gpUserProfile['given_name'],
          'last_name'     => $gpUserProfile['family_name'],
          'email'         => $gpUserProfile['email'],
          'gender'        => $gpUserProfile['gender'],
          'locale'        => $gpUserProfile['locale'],
          'picture'       => $gpUserProfile['picture'],
          'link'          => $gpUserProfile['link']
      );
      $userData = $user->checkUser($gpUserData);
    
    //Storing user data into session
    $_SESSION['userData'] = $userData;
    
    //Render facebook profile data
      if(!empty($userData)){
          $output = '<h1>Google+ Profile Details </h1>';
          $output .= '<img src="'.$userData['picture'].'" width="300" height="220">';
          $output .= '<br/>Google ID : ' . $userData['oauth_uid'];
          $output .= '<br/>Name : ' . $userData['first_name'].' '.$userData['last_name'];
          $output .= '<br/>Email : ' . $userData['email'];
          $output .= '<br/>Gender : ' . $userData['gender'];
          $output .= '<br/>Locale : ' . $userData['locale'];
          $output .= '<br/>Logged in with : Google';
          $output .= '<br/><a href="'.$userData['link'].'" target="_blank">Click to Visit Google+ Page</a>';
          $output .= '<br/>Logout from <a href="logout.php">Google</a>'; 
      }else{
          $output = '<h3 style="color:red">Some problem occurred, please try again.</h3>';
      }
  } else {
    $authUrl = $gClient->createAuthUrl();
    $output = '<a href="'.filter_var($authUrl, FILTER_SANITIZE_URL).'"><img src="images/glogin.png" alt=""/ style="height:150px;width:300px;margin-left:100px"></a>';
   
  }
  ?>
  <html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Login with Google using PHP by CodexWorld</title>
  <style type="text/css">
  h1{font-family:Arial, Helvetica, sans-serif;color:#999999;}
  </style>
  </head>
  <body>
  <div><?php echo $output; ?></div>
  </body>
  </html></div>
          <a href="forget.php">Forget Password</a>
          <!-- Modal footer -->
          <div class="modal-footer">
            <div class="col-sm-1">
           <input type="submit" name="signup">
         </div>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div></form>
          
        </div>
      </div>
    </div></li>
    <li><a data-toggle="modal" data-target="#mysignup" data-backdrop="false">
      Sign Up
    </a>

    <!-- The Modal -->
    <div class="modal fade" id="mysignup">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
        
          <!-- Modal Header -->
            <div class="modal-header">
                  <button type="button" class="close" 
                     data-dismiss="modal">
                         <span aria-hidden="true">&times;</span>
                         <span class="sr-only">Close</span>
                  </button>
                  <center><h4 class="modal-title" id="myModalLabel">
                      Sign Up
                  </h4></center>
              </div>
              
              <!-- Modal Body -->
              <div class="modal-body">
                  
                  <form class="form-horizontal" role="form" action="signup.php" method="POST">
                    <div class="form-group">
                      <label  class="col-sm-3 control-label"
                                for="inputText3">First Name</label>
                      <div class="col-sm-9">
                          <input type="inputText3" class="form-control" 
                          id="inputfname3" name="inputfname3" placeholder="First Name" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Last Name</label>
                      <div class="col-sm-9">
                          <input type="inputText3" class="form-control"
                              id="inputlname3"  name="inputlname3" placeholder="Last Name" required>
                      </div>
                    </div>
                    
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputdate3" >Birthday</label>
                      <div class="col-sm-9">
                          <input type="inputdate3" class="form-control"
                              id="inputdate3" id="inputDate3" placeholder="mm/dd/yy" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Mobile No.</label>
                      <div class="col-sm-9">
                          <input type="inputtext3" class="form-control"
                              id="inputmobile3" name="inputmobile3" placeholder="Mobile No." required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Adhar No.</label>
                      <div class="col-sm-9">
                          <input type="inputext3" class="form-control"
                              id="inputadhar3" placeholder="Adhar No." required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="email" >Email</label>
                      <div class="col-sm-9">
                          <input type="email" class="form-control"
                              id="inputEmail3"  name="inputEmail3" placeholder="Email" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputPassword3" >Password</label>
                      <div class="col-sm-9">
                          <input type="password" class="form-control"
                              id="inputPassword3"  name="inputPassword3" placeholder="Password" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Address</label>
                      <div class="col-sm-9">
                          <input type="inputText3" class="form-control"
                              id="inputaddress3" name="inputaddress3" placeholder="Address" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-sm-offset-2 col-sm-10">
                        <div class="checkbox">
                          <label>
                              <input type="checkbox"/> Remember me
                          </label>
                        </div>
                      </div>
                    </div>              
              </div>
          
          <!-- Modal footer -->
          <div class="modal-footer">
            <div class="col-sm-1">
           <input type="submit" name="signup">
         </div>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div></form>
          
        </div>
      </div>
    </div></li>
    </ul>
  </div>

      </div><?php } ?>
      
    </div>

  </div>
<br><br><br><br>
<div class="row">
  <img src="image/w1.jpg" style="width: 100%;height: 400px">
</div>
<div style="position: absolute;top:80px; left:0;width: 100%; height: 400px; background-color: rgba(0,0,0,0.7); ">
      <div style="display: flex;justify-content: center;margin-top: 150px;">
        <center><div><div><font style="font-size: 70px; color: white;"><b>Event List</b></font></div>
    </div>
    </center>
  </div>
</div><br><br><br>

<div class="row">
  <center><font style="font-size: 25px;color: brown">Event</font></center>
  <center><font style="font-size: 50px;"><b>Splendid & Luxurious</b></font></center>
  <center><font style="font-size: 35px;color: brown"><p>______</p></font></center><br><br>
  <div class="col-md-3"></div>
  <div class="col-md-7">
    <font style="font-size: 15px;color: grey">Our services are affordable and are of top quality. We make sure that whatever we do, we put our best foot forward. This is why we are considered among the preferred wedding planners,other organisers and entertainers. The trust of our clients is another very important factor in our service. We are fully dedicated to our clients’ requirements. This is why we have the customized services. Be it bartending, themes, dancers, DJs or anything else, we organize them in the ways our client desires.We are an event and activation company driven by enthusiasm and passion. We are a team of highly dedicated professionals with years of experience behind them in executing and managing various events that leaves no stone unturned. And our experience is backed by our rock solid organizational skills and process management. With our strong strategic planning, creative thoughts and great execution makes we try and give our clients, an experience which can never be forgotten.
.</font>
  </div>
</div><br><br><br><br><br>

<div class="row">
  <div class="col-md-6">
    <img src="image/wed26.jpg" style="width: 102%;height: 479px; ">
  </div>
  <div class="col-md-6 well"><br><br>
    <font style="font-size: 25px;color: brown">WEDDING</font><br>
    <font style="font-size: 45px;"><b>Modern & Professional</b></font><br>
    <font style="font-size: 30px;color: brown">________</font><br><br><br>
    <font style="font-size: 15px;color: grey">Our talented group of wedding experts are the perfect match for your needs. We cover everything – from the decoration, the venue, the guest list, the entertainment and photography! 
Our management is the best in the business. Our passion for photography is translated into beautiful snapshots that brides and grooms can keep forever.Our photography specialist will always share original wedding photography ideas with you. He always likes to spend some time with each couple before they tie the knot to get to know them a bit better and be able to capture their true essence. A genuine advocate of naturalness, perfect wedding. </font><br><br><br>
    <button class="btn btn-secondary" style="width: 20%; height: 50px"><b><a href="event.php"> Our Venue</a></b></button>
  </div>
</div>

<div class="row">
  <div class="col-md-6 well" style="margin-top: -19px;"><br><br>
    <font style="font-size: 25px;color: brown;margin-left: 25px">CONFRENCE</font><br>
    <font style="font-size: 45px; margin-left: 25px"><b>Best and Effective</b></font><br>
    <font style="font-size: 30px;color: brown;margin-left: 25px">________</font><br><br><br>
    <font style="font-size: 15px;color: grey;margin-left: 25px">Our dedicated team of Conference Organizer and specialists will devote their expertise and enthusiasm to making your conference, event, exhibition or seminar successful and productive clients most successfully. We are providing effective conference organisers(Corporate Anniversary Event) to the customers. We always understand the preference of the customers and their needs.</font><br><br><br>
    <button class="btn btn-secondary" style="width: 20%; height: 50px"><b><a href="event.php"> Our Venue</a></b></button>
  </div>
  <div class="col-md-6">
    <img src="image/con8.jpg" style="width: 102%;height: 455px;margin-left: -13px;margin-top: -19px ">
  </div>
</div>

<div class="row">
  <div class="col-md-6">
    <img src="image/birthday1.jpg" style="width: 102%;height: 475px;margin-top: -19px ">
  </div>
  <div class="col-md-6 well" style="margin-top: -19px"><br><br>
    <font style="font-size: 25px;color: brown;margin-left: 10px">BIRTHDAY PARTY</font><br>
    <font style="font-size: 45px;"><b>Fun and Memorable</b></font><br>
    <font style="font-size: 30px;color: brown">________</font><br><br><br>
    <font style="font-size: 15px;color: grey">When you've got a big event to plan, Birthday Party and hundreds of guests are coming, the food and drinks needs to be perfect, but you've got no time to even think about the preparation. That's when you need to hire a good organiser, who employs the services of the best things.KALIEDEOSCOPE serve you best service in as we serve you with the top-notch quality.We design Your Menus for your occasion, to your preference, befitting your destination, theme and budget. Our Cuisines will not only take you all around the world but also through exotic regional flavors of our country.

 </font><br><br><br>
    <button class="btn btn-secondary" style="width: 20%; height: 50px"><b><a href="event.php"> Our Venue</a></b></button>
  </div>
</div>


<div class="row">
  <div class="col-md-6 well" style="margin-top: -19px;"><br><br>
    <font style="font-size: 25px;color: brown;margin-left: 25px">BUSINESS MEETINGS </font><br>
    <font style="font-size: 45px;margin-left: 25px"><b>Professional & Comfortable</b></font><br>
    <font style="font-size: 30px;color: brown;margin-left: 25px">________</font><br><br><br>
    <font style="font-size: 15px;color: grey;margin-left: 25px">You have meetings every few months where all the key associate members of the organization along with the board of directors sit together to discuss the regular agendas and accomplishments of the organization. Well, you will certainly need proper planning for venue and refreshments for these meetings too and we know exactly how to arrange for the perfect corporate settings.We truly believe in accomplishing our job to the “T”, just the way you like your business to be!</font><br><br><br>
    <button class="btn btn-secondary" style="width: 20%; height: 50px"><b><a href="event.php"> Our Venue</a></b></button>
  </div>
  <div class="col-md-6">
    <img src="image/b3.jpg" style="width: 102%;height: 455px;margin-left: -13px;margin-top: -19px ">
  </div>
</div>

<div class="row">
  <div class="col-md-6">
    <img src="image/music1.jpg" style="width: 102%;height: 455px;margin-top: -19px ">
  </div>
  <div class="col-md-6 well" style="margin-top: -19px"><br><br>
    <font style="font-size: 25px;color: brown">MUSIC CONCERTS</font><br>
    <font style="font-size: 45px;"><b>Rocking and Fun</b></font><br>
    <font style="font-size: 30px;color: brown">________</font><br><br><br>
    <font style="font-size: 15px;color: grey">To bring a fresh feel in air, people are nowadays opting for them. We at Knockout DJs and Entertainers with additional services. Some of our offers and varieties in musical entertainment are unique and best.
       Our live singers are talented and they hold considerable experience. They cater to the special demands of the guests in concets. They have their own band and technical support as well. We even provide the dancers and drummers.
.</font><br><br><br>
    <button class="btn btn-secondary" style="width: 20%; height: 50px"><b><a href="event.php"> Our Venue</a></b></button>
  </div>
</div><br><br><br><br>

  <?php 
$servername="localhost";
$username="root";
$password="";
$dbname="event";
$conn=mysqli_connect($servername,$username,$password,$dbname);

$sql="SELECT `name`, `location`, `date`, `city`, `organizer`, `mobile`, `comment` FROM `admin`";
$result=mysqli_query($conn,$sql);$i=0;
  if (mysqli_num_rows($result)) {
    while($row=mysqli_fetch_assoc($result)){
      if($i%2=="0")
      {
        ?>
      <div>
        <div class="col-md-6">
    <img src="image/w1.jpg" style="width: 102%;height: 455px;margin-left: -13px;margin-top: -19px ">
  </div><div class="col-md-6 well" style="margin-top: -19px;"><br><br>
    <font style="font-size: 25px;color: brown;margin-left: 25px;"><?php echo $row['name']; ?></font><br>
    <font style="font-size: 45px;margin-left: 25px"><b>Modern & Professional</b></font><br>
    <font style="font-size: 30px;color: brown;margin-left: 25px">________</font><br><br><br>
    <font style="font-size: 15px;color: grey;margin-left: 25px">Lorem Khaled Ipsum is a major key to success. Bless up. The weather is amazing, walk with me through the pathway of more success. Take this journey with me, Lion! Let me be clear, you have to make it through the jungle to make it to paradise, that’s the key, Lion! Wraith talk. They key is to have every key, the key to open every door. Put it this way, it took me twenty five years to get these plants, twenty five years of blood sweat and tears, and I’m never giving up, I’m just getting started.</font><br><br><br>
    <button class="btn btn-secondary" style="width: 20%; height: 50px"><b><a href="event.php"> Our Venue</a></b></button>
  </div>
    </div>
  <?php }
    else{
      ?>
      <div>
      <div class="col-md-6 well" style="margin-top: -19px;"><br><br>
    <font style="font-size: 25px;color: brown;margin-left: 25px;"><?php echo $row['name']; ?></font><br>
    <font style="font-size: 45px;margin-left: 25px"><b>Modern & Professional</b></font><br>
    <font style="font-size: 30px;color: brown;margin-left: 25px">________</font><br><br><br>
    <font style="font-size: 15px;color: grey;margin-left: 25px">Lorem Khaled Ipsum is a major key to success. Bless up. The weather is amazing, walk with me through the pathway of more success. Take this journey with me, Lion! Let me be clear, you have to make it through the jungle to make it to paradise, that’s the key, Lion! Wraith talk. They key is to have every key, the key to open every door. Put it this way, it took me twenty five years to get these plants, twenty five years of blood sweat and tears, and I’m never giving up, I’m just getting started.</font><br><br><br>
    <button class="btn btn-secondary" style="width: 20%; height: 50px"><b><a href="event.php"> Our Venue</a></b></button>
  </div>
    <div class="col-md-6">
    <img src="image/w1.jpg" style="width: 102%;height: 455px;margin-left: -13px;margin-top: -19px ">
  </div>
    </div>
  <?php
    }$i++;
}
}
 
 ?>

<div class="row">
<center><font style="font-size: 50px;color: red;"><b>Photo Gallery</b></font></center><br><br>
  <div class="conatiner" style="width: 100%;height: 400px;margin-left: 100px">
    <div class="box">
      <div class="imgBox">
        <img src="image/wed5.jpg" style="width: 100%;height: 200%">
      </div>
      <div class="details">
        <div class="content">
           <h2>Weeding</h2>
           <p>luv for life</p>
           </div> 
         </div>
       </div>
       <div class="box">
      <div class="imgBox">
        <img src="image/birthday2.jpg">
      </div>
      <div class="details">
        <div class="content">
           <h2>Birthday</h2>
           <p>Born on the spacial day</p>
           </div> 
         </div>
       </div>
    <div class="box">
      <div class="imgBox">
        <img src="image/con5.jpg">
      </div>
      <div class="details">
        <div class="content">
           <h2>Conference</h2>
           <p>Step towards Innovation</p>
           </div> 
         </div>
       </div>
    <div class="box">
      <div class="imgBox">
        <img src="image/b5.jpg">
      </div>
      <div class="details">
        <div class="content">
           <h2>Business Meeting</h2>
           <p>Making profit</p>
           </div> 
         </div>
       </div>
    <div class="box">
      <div class="imgBox">
        <img src="image/e2.jpg">
      </div>
      <div class="details">
        <div class="content">
           <h2>Engagement</h2>
           <p>New journey with new partner</p>
           </div> 
         </div>
       </div>
    <div class="box">
      <div class="imgBox">
        <img src="image/music5.jpg">
      </div>
      <div class="details">
        <div class="content">
           <h2>Music</h2>
           <p>Fun and enjoyment/p>
           </div> 
         </div>
       </div>
    <div class="box">
      <div class="imgBox">
        <img src="image/wed5.jpg">
      </div>
      <div class="details">
        <div class="content">
           <h2>Satyam</h2>
           <p>one of the best</p>
           </div> 
         </div>
       </div>
    <div class="box">
      <div class="imgBox">
        <img src="image/wed5.jpg">
      </div>
      <div class="details">
        <div class="content">
           <h2>Satyam</h2>
           <p>one of the best</p>
           </div> 
         </div>
       </div>
    
     </div>
  </div><br><br><br>
<div class="row well" style="background-color: #0C0C0C;">  
      <div class="col-sm-3 well" style="background-color: #0C0C0C; font-size: 15px; color: white;border:none;border-right: 2px solid;height: 200px;">Disclaimer <br>FAQ <br> Terms & Condition <br> About Us <br> Privacy Policy</div>
      <div class="col-sm-3 col-sm-offset-1 well" style="background-color: #0C0C0C; height: 200px;font-size: 15px; color: white;border:none;border-right: 2px solid;"><u style="font-size: 20px;">Follow Us On</u><br>Facebook <br>Instagram <br> Google+<br> Twitter</div>
      <div class="col-sm-3 col-sm-offset-2 well" style="background-color: #0C0C0C; font-size: 15px;height: 200px; color: white;border:none;border-right: 2px solid;">
        Event Management System <br> 13/14 Saraswati Bihar,Goner Phtak <br> Jaipur city,302022 <br> Distt. Jaipur <br> Rajasthan <br>E-mail:-kaleidoscope@gmail.com <br>Contact No:- 1234567890
      </div>





</div>
</body>
</html>