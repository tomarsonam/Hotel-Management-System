<?php

//Include Google client library 
include_once 'src/Google_Client.php';
include_once 'src/contrib/Google_Oauth2Service.php';

/*
 * Configuration and setup Google API
 */
$clientId = '19626137068-lopv4mjdaqgqm20hpoeinb1nuc7rbqcp.apps.googleusercontent.com'; //Google client ID
$clientSecret = '6z7jFfVR2T6tyiUtm_MkZcMj'; //Google client secret
$redirectURL = 'http://satyamranjan4035.000webhostapp.com'; //Callback URL

//Call Google API
$gClient = new Google_Client();
$gClient->setApplicationName('Login to CodexWorld.com');
$gClient->setClientId($clientId);
$gClient->setClientSecret($clientSecret);
$gClient->setRedirectUri($redirectURL);

$google_oauthV2 = new Google_Oauth2Service($gClient);
?>