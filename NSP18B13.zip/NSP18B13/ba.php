<?php
  session_start();
    ?>
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <title>Home page</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="js/bootstrap.min.css">
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>

  </head><style>
  input[type=text],[type=submit],[type=date]
  {margin-top: 20%;
    height: 70px;width: 200px;
    padding: 20px;outline:none;

  }
  body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
  }
  body {
    background: #f6f6f6;
    }
.countdownContainer{
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translateX(-50%) translateY(-50%);
  text-align: center;
  font-color:red;
   border: 1px solid #999;
   font-size: 30px;
   padding: 10px;
   box-shadow: 0 0 5px 3px #ccc;
 }
 .info{
  font-size: 100px
 }
  .container{
    max-width: 1000px;
  }
  .header {
      padding: 30px;
      text-align: center;
      background: #1abc9c;
      color: white;
  }

  .topnav {
    overflow: hidden;
    background-color: #333;
  }

  .topnav a {
    float: left;
    display: block;
    color: #f2f2f2;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
  }

  .topnav a:hover {
    background-color: #ddd;
    color: black;
  }

  .active {
    background-color: #4CAF50;
    color: white;
  }

  .topnav .icon {
    display: none;
  }

  @media screen and (max-width: 600px) {
    .topnav a:not(:first-child) {display: none;}
    .topnav a.icon {
      float: right;
      display: block;
    }
  }

  @media screen and (max-width: 600px) {
    .topnav.responsive {position: relative;}
    .topnav.responsive .icon {
      position: absolute;
      right: 0;
      top: 0;
    }
    .topnav.responsive a {
      float: none;
      display: block;
      text-align: left;
    }
  }
  h2 {
      color: white;
      text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;
  }
  h1 {
      color: white;
      text-shadow: 2px 2px 4px #000000;
  }
  h1 {
      text-shadow: 0 0 3px #FF0000;
  }
  </style>
  </head>
  <body>



  <script>
  function myFunction() {
      var x = document.getElementById("myTopnav");
      if (x.className === "topnav") {
          x.className += " responsive";
      } else {
          x.className = "topnav";
      }
  }

  </script>

  <div class="container-fluid">
    <div class="row">

      <div class="navbar navbar-inverse navbar-fixed-top " style="background-color: white;font-size: 18px">

        <ul class="nav nav-tabs">
         
      <li ><a href="#" style="margin-top: 50px">Home</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="margin-top: 50px">Event<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="eventlist.php">Event list</a></li>
          <li><a href="event.php">Event venue</a></li>                      
        </ul>
      </li>
     <li><a href="services.php" style="margin-top: 50px">Services</a></li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="margin-top: 50px">Gallery<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="gwed.php">Wedding</a></li>
          <li><a href="gbirth.php">Birthday</a></li>
          <li><a href="gmusic.php">Music-concerts</a></li>
          <li><a href="gconf.php">Conference</a></li>
          <li><a href="gbusi.php">Business Meetings</a></li>
          <li><a href="genag.php">Engagements</a></li>                        
        </ul>
      </li>
      <li class="dropdown">
        <a class="dropdown-toggle" data-toggle="dropdown" href="#" style="margin-top: 50px">Pages<span class="caret"></span></a>
        <ul class="dropdown-menu">
          <li><a href="pdetail.php">Detail page</a></li>
          <li><a href="#">My Profile</a></li>
          <li><a href="#">Edit profile</a></li>
          <li><a href="pblog.php">Blog</a></li>   
          <li><a href="privacy.php">Privacy policy</a></li> 
          <li><a href="piechart.html">Chart</a></li> 
          <li><a href="pteam.php">Team</a></li>                       
        </ul>
      </li>
      <li><a href="booknow.php" style="margin-top: 50px">Book Now</a></li>
      <li><a href="about.php" style="margin-top: 50px">About us</a></li>
      <li><a href="faq.php" style="margin-top: 50px">FAQ'S</a></li>
      <li><a href="contact.php" style="margin-top: 50px">Contact us</a></li>
      <?php if(!empty($_SESSION["name"])) { 
          echo "<li><a>".$_SESSION["name"]."</a></li>";
          echo "<li><a href='logout.php'>Logout</a></li>";
        if($_SESSION["TYPE"]=="admin"){
       echo "<li><a href='admin.php'>Admin</a></li>";
        } }else{
        ?>
      <li><a data-toggle="modal" data-target="#myModal" data-backdrop="false" style="margin-left:400px ">
      Login
    </a>

    <!-- The Modal -->
    <div class="modal fade" id="myModal">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
        
          <!-- Modal Header -->
            <div class="modal-header">
                  <button type="button" class="close" 
                     data-dismiss="modal">
                         <span aria-hidden="true">&times;</span>
                         <span class="sr-only">Close</span>
                  </button>
                 <center> <h4 class="modal-title" id="myModalLabel">
                      Login
                  </h4></center>
              </div>
              
              <!-- Modal Body -->
              <div class="modal-body">
                  
                  <form action="login.php" method="POST" class="form-horizontal" role="form">
                    <div class="form-group">
                      <label  class="col-sm-3 control-label"
                                for="inputEmail3">Email</label>
                      <div class="col-sm-7">
                          <input type="email" class="form-control" 
                          id="inputEmail3" name="inputEmail3" placeholder="Email" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputPassword3" >Password</label>
                      <div class="col-sm-7">
                          <input type="password" class="form-control"
                              id="inputPassword3" name="inputPassword3" placeholder="Password" required>
                      </div>
                    </div>
                    

                    <div class="form-group">
                      <div class="col-sm-offset-2 col-sm-10">
                        <div class="checkbox">
                          <label>
                              <input type="checkbox"/> Remember me
                          </label>
                        </div>
                      </div>
                    </div>              
              <?php
  //Include GP config file && User class
  include_once 'gpConfig.php';
  include_once 'User.php';

  if(isset($_GET['code'])){
    $gClient->authenticate($_GET['code']);
    $_SESSION['token'] = $gClient->getAccessToken();
    header('Location: ' . filter_var($redirectURL, FILTER_SANITIZE_URL));
  }

  if (isset($_SESSION['token'])) {
    $gClient->setAccessToken($_SESSION['token']);
  }

  if ($gClient->getAccessToken()) {
    //Get user profile data from google
    $gpUserProfile = $google_oauthV2->userinfo->get();
    
    //Initialize User class
    $user = new User();
    
    //Insert or update user data to the database
      $gpUserData = array(
          'oauth_provider'=> 'google',
          'oauth_uid'     => $gpUserProfile['id'],
          'first_name'    => $gpUserProfile['given_name'],
          'last_name'     => $gpUserProfile['family_name'],
          'email'         => $gpUserProfile['email'],
          'gender'        => $gpUserProfile['gender'],
          'locale'        => $gpUserProfile['locale'],
          'picture'       => $gpUserProfile['picture'],
          'link'          => $gpUserProfile['link']
      );
      $userData = $user->checkUser($gpUserData);
    
    //Storing user data into session
    $_SESSION['userData'] = $userData;
    
    //Render facebook profile data
      if(!empty($userData)){
          $output = '<h1>Google+ Profile Details </h1>';
          $output .= '<img src="'.$userData['picture'].'" width="300" height="220">';
          $output .= '<br/>Google ID : ' . $userData['oauth_uid'];
          $output .= '<br/>Name : ' . $userData['first_name'].' '.$userData['last_name'];
          $output .= '<br/>Email : ' . $userData['email'];
          $output .= '<br/>Gender : ' . $userData['gender'];
          $output .= '<br/>Locale : ' . $userData['locale'];
          $output .= '<br/>Logged in with : Google';
          $output .= '<br/><a href="'.$userData['link'].'" target="_blank">Click to Visit Google+ Page</a>';
          $output .= '<br/>Logout from <a href="logout.php">Google</a>'; 
      }else{
          $output = '<h3 style="color:red">Some problem occurred, please try again.</h3>';
      }
  } else {
    $authUrl = $gClient->createAuthUrl();
    $output = '<a href="'.filter_var($authUrl, FILTER_SANITIZE_URL).'"><img src="images/glogin.png" alt=""/ style="height:150px;width:300px;margin-left:100px"></a>';
   
  }
  ?>
  <html>
  <head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Login with Google using PHP by CodexWorld</title>
  <style type="text/css">
  h1{font-family:Arial, Helvetica, sans-serif;color:#999999;}
  </style>
  </head>
  <body>
  <div><?php echo $output; ?></div>
  </body>
  </html></div>
          <a href="forget.php">Forget Password</a>
          <!-- Modal footer -->
          <div class="modal-footer">
            <div class="col-sm-1">
           <input type="submit" name="signup">
         </div>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div></form>
          
        </div>
      </div>
    </div></li>
    <li><a data-toggle="modal" data-target="#mysignup" data-backdrop="false">
      Sign Up
    </a>

    <!-- The Modal -->
    <div class="modal fade" id="mysignup">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
        
          <!-- Modal Header -->
            <div class="modal-header">
                  <button type="button" class="close" 
                     data-dismiss="modal">
                         <span aria-hidden="true">&times;</span>
                         <span class="sr-only">Close</span>
                  </button>
                  <center><h4 class="modal-title" id="myModalLabel">
                      Sign Up
                  </h4></center>
              </div>
              
              <!-- Modal Body -->
              <div class="modal-body">
                  
                  <form class="form-horizontal" role="form" action="signup.php" method="POST">
                    <div class="form-group">
                      <label  class="col-sm-3 control-label"
                                for="inputText3">First Name</label>
                      <div class="col-sm-9">
                          <input type="inputText3" class="form-control" 
                          id="inputfname3" name="inputfname3" placeholder="First Name" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Last Name</label>
                      <div class="col-sm-9">
                          <input type="inputText3" class="form-control"
                              id="inputlname3"  name="inputlname3" placeholder="Last Name" required>
                      </div>
                    </div>
                    
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputdate3" >Birthday</label>
                      <div class="col-sm-9">
                          <input type="inputdate3" class="form-control"
                              id="inputdate3" id="inputDate3" placeholder="mm/dd/yy" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Mobile No.</label>
                      <div class="col-sm-9">
                          <input type="inputtext3" class="form-control"
                              id="inputmobile3" name="inputmobile3" placeholder="Mobile No." required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Adhar No.</label>
                      <div class="col-sm-9">
                          <input type="inputext3" class="form-control"
                              id="inputadhar3" placeholder="Adhar No." required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="email" >Email</label>
                      <div class="col-sm-9">
                          <input type="email" class="form-control"
                              id="inputEmail3"  name="inputEmail3" placeholder="Email" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputPassword3" >Password</label>
                      <div class="col-sm-9">
                          <input type="password" class="form-control"
                              id="inputPassword3"  name="inputPassword3" placeholder="Password" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="col-sm-3 control-label"
                            for="inputtext3" >Address</label>
                      <div class="col-sm-9">
                          <input type="inputText3" class="form-control"
                              id="inputaddress3" name="inputaddress3" placeholder="Address" required>
                      </div>
                    </div>
                    <div class="form-group">
                      <div class="col-sm-offset-2 col-sm-10">
                        <div class="checkbox">
                          <label>
                              <input type="checkbox"/> Remember me
                          </label>
                        </div>
                      </div>
                    </div>              
              </div>
          
          <!-- Modal footer -->
          <div class="modal-footer">
            <div class="col-sm-1">
           <input type="submit" name="signup">
         </div>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div></form>
          
        </div>
      </div>
    </div></li>
    </ul>
  </div>

      </div><?php } ?>
      
    </div>

  </div>
<br><br><br><br><br><br>
  	 <img src="image/about.png" class="img-responsive" alt="Cinque Terre" style="width: 100%; height: 350px;" > 
  	</div>
    </div><br><br><br>
    <div class="row">
      <div class="col-md-1"></div>
      <div class="col-md-10">
      <center><font style="font-size: 30px"><b>Welcome to our website</b></font></center>
      <center><p>______________________</p></center><br>
      <center><font style="font-size: 20px;color: grey">All the information you will need is listed below, just click on the page you want to view and that's it.
</font></center>
<center><font style="font-size: 40px;color: tomato"><p>_____</p></font></center><br><br>
<center><font style="font-size: 15px;color: grey"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation<br> ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>

<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi<br> architecto beatae vitae dicta sunt explicabo.</p>

<p>Nullam elementum nisi eget mi mollis laoreet. Morbi non dignissim tellus, vitae blandit urna Lorem ipsum dolor sit amet, consectetur adipiscing elit morbi non dignissim.Nullam<br> elementum nisi eget mi mollis laoreet. Morbi non dignissim tellus, vitae blandit urna Lorem ipsum dolor sit amet, consectetur adipiscing elit morbi non dignissim.</p></font></center>
    </div>
  </div><br><br>
  <div class="row">
    <div class="col-md-12">
      <div class="col-md-6" style="background-color:  #00001a;width: 50%;height: 600px"><br><br>
        <font style="font-size:40px;color: white">Lorem Ipsum <b>dummy</b> text</font><br><br>
        <font style="font-size: 20px;color: white">A them above good above i creeping all don’t living together let kind. Void beginning set said days beginning moveth night fifth fill. Created likeness made saying third she’d don’t saw, she’d creeping subdue firmament stars a was for seed cattle without winged. Itself isn’t from god lesser their fourth image first greater it fifth moving after to upon from our gathering fowl. Were isn’t air fruit let midst first, fill shall evening make from very. Sea it greater day image which, night rule him made waters saying form. Living of replenish without fruitful above Signs the image him land gathering all.</font><br><br><br>
        <center><font style="font-size: 50px;"><button class="btn btn-secondary" style="font-size: 35px;color:#000033;background-color:white;border-color: white "> READ MORE</button></font></center>
      </div>
      <div class="col-md-6">
        <img src="image/w1.jpg" style="width: 120%; height: 600px;margin-left: -15px">
      </div>
    </div>
  </div><br><br><br>
  <div class="row">
    <div class="col-md-6">
      <div class="col-md-2"></div>
      <div class="col-md-10">
        <font style="font-size: 20px"><b>Our Vision</b></font><br><br>
        <font style="font-size: 14px;color: grey"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam elementum nisi eget mi mollis laoreet. Morbi non dignissim tellus, vitae blandit urna Lorem ipsum dolor sit amet, consectetur adipiscing elit morbi non dignissim. Nullam elementum nisi eget mi mollis laoreet. Morbi non dignissim tellus, vitae blandit urna Lorem ipsum dolor sit amet, consectetur adipiscing elit morbi non dignissim.</p><br>

<p>Nullam elementum nisi eget mi mollis laoreet. Morbi non dignissim tellus, vitae blandit urna Lorem ipsum dolor sit amet, consectetur adipiscing elit morbi non dignissim.</p>
</font>
      </div>
    </div>
      <div class="col-md-6">
        <div class="col-md-10">
          <font style="font-size: 20px"><b>Core Goal</b></font><br><br>
          <font style="font-size: 14px;color: grey"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Nullam elementum nisi eget mi mollis laoreet.</p>
<p>Morbi non dignissim tellus, vitae blandit urna Lorem ipsum dolor sit amet, consectetur adipiscing elit morbi non dignissim.</p>
<p>Nullam elementum nisi eget mi mollis laoreet.</p>
<p>Morbi non dignissim tellus, vitae blandit urna Lorem ipsum dolor sit amet, consectetur adipiscing elit morbi non dignissim.</p></font>
        </div>
      </div>
    </div>
  </div><br>
  <div class="row">
    <div class="col-md-10 col-md-offset-1">
      <font style="font-size: 20px;"><b>Objective</b></font><br><br>
      <font style="font-size: 15px;color: grey"><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>

<p>Nullam elementum nisi eget mi mollis laoreet. Morbi non dignissim tellus, vitae blandit urna Lorem ipsum dolor sit amet, consectetur adipiscing elit morbi non dignissim.Nullam elementum nisi eget mi mollis laoreet. Morbi non dignissim tellus, vitae blandit urna Lorem ipsum dolor sit amet, consectetur adipiscing elit morbi non dignissim.</p></font>
    </div>
  </div><br><br>
  
  <div class="row">
    <img src="image/w1.jpg" style="width: 100%;height: 500px">
   <div style="position: absolute;top:2050px; left:0;width: 100%; height:500px; background-color:tomato;
opacity: 0.9 ">
      <div style="display: flex;justify-content: center;margin-top: 150px;">
              <table class="countdownContainer">
    <tr class="info">
      <td colspan="4">Our Upcoming Event</td>
    </tr>
    <tr>
      <td id="days">120</td>
      <td id="hours">4</td>
      <td id="minutes">12</td>
      <td id="seconds">22</td>
    </tr>
    <tr>
    <td>Days</td>
    <td>Hours</td>
    <td>Minutes</td>
    <td>Seconds</td>
  </tr>
  </table>
  <script type="text/javascript">
    function countdown(){
      var now = new Date();
      var eventDate = new Date(2019,10,21);

      var currentTime = now.getTime();
      var eventTime = eventDate.getTime();

      var remTime= eventTime - currentTime;

      var s = Math.floor(remTime/1000);
      var m = Math.floor(s/60);
      var h = Math.floor(m/60);
      var d = Math.floor(h/24);

      h %=24;
      m %=60;
      s %=60;
       
       h = (h < 10) ? "0" + h : h;
       m = (m < 10) ? "0" + m : m;
       s = (s < 10) ? "0" + s : s;

       document.getElementById("days").textContent = d;
        document.getElementById("days").textContent = d;

         document.getElementById("hours").textContent = h;
          document.getElementById("minutes").textContent = m;
           document.getElementById("seconds").textContent = s;

           setTimeout(countdown, 1000);

       }

       countdown();
  </script>

    </div>
  </div>
</div><br><br>








    <div class="row well" style="background-color: grey;">  
      <div class="col-sm-3 well" style="background-color: grey; font-size: 18px; color: white ;border:none;border-right: 2px solid;height: 300px;">Disclaimer <br>FAQ <br> Terms & Condition <br> About Us <br> Privacy Policy</div>
      <div class="col-sm-3 col-sm-offset-1 well" style="background-color: grey; height: 300px;font-size: 18px; color: white;border:none;border-right: 2px solid;"><u style="font-size: 20px;">Follow Us On</u><br>Facebook <br>Instagram <br> Google+<br> Twitter</div>
      <div class="col-sm-3 col-sm-offset-2 well" style="background-color: grey; font-size: 18px;height: 300px; color: white;border:none;border-right: 2px solid;">
        Event Management System <br> 13/14 Saraswati Bihar,Goner Phtak <br> Jaipur city,302022 <br> Distt. Jaipur <br> Rajasthan <br>E-mail:-kaleidoscope@gmail.com <br>Contact No:- 1234567890
  </div>
</body>
</html>
