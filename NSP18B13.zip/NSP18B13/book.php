<?php
$a=$_POST['event'];
$b=$_POST['city'];
$c=$_POST['venue'];
$d=$_POST['person'];
$e=$_POST['date'];
$f=$_POST['service'];
$servername="localhost";
$username="root";
$password="";
$dbname="db_users";
$conn=mysqli_connect($servername,$username,$password,$dbname);
$sql="INSERT INTO `book`(`Eventname`, `Eventcity`, `location`, `person`, `date`, `services`) VALUES ('$a','$b','$c','$d','$e','$f')";
if(mysqli_query($conn,$sql))
{ 	

	echo"<script> alert ('Event selected successfully');
	      window.location.assign('index.php')</script>";
}
else
{
	echo"not";
}
mysqli_close($conn);
?>